const moment = require("moment");

exports.handler = async (event, context, callback) => {
    let currentTime = moment().format('LT');
    let currentDate = moment().format("MMM Do YYYY");
    callback(null, {
        statusCode: '200',
        body: `The time is ${currentTime} on ${currentDate}.`
    });
};
